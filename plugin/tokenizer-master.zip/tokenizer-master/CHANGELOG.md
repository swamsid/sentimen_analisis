CHANGELOG
=========

* 0.4.0 (2015-01-21)

  * menambah option pada CLI (Command Line Interface)

* 0.3.0 (2015-01-18)

  * menambah CLI (Command Line Interface)

* 0.2.0 (2014-12-28)

  * menangani karakter hyphen (-) agar tidak memisah kata berulang: rumah-rumah.
  * menangani karakter double hyphen (--) agar tidak memisah pemisah kalimat.

* 0.1.0 (2014-12-04)

  * rilis pertama tokenizer.
  * memisah token berdasarkan tanda baca: . , ; : dan lainnya.
  * menangani entity supaya tidak dipisah seperti singkatan, pemisah angka, dan lainnya.
